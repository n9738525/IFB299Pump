<!DOCTYPE html>
<html>
    <html lang="en"
    xmlns="http://www.w3.org/1999/xhtml"
    xmlns:f="http://xmlns.jcp.org/jsf/core"
    xmlns:h="http://xmlns.jcp.org/jsf/html"
    xmlns:ui="http://xmlns.jcp.org/jsf/facelets">
<head>
    <title>Parent_homepage</title>
    <style>
    body, html {
  width: 100%;
  height: 100%;
  margin: 0;
    padding: 0;
    background: url(music.jpg);
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    }
        
.navbar{
         width:100%;
            
            text-align: center
                width:100%;
            
            height: 80px;
            margin-top: 0px;
           
            
        }
        
        .navbar ul{
            position: relative;
            list-style:none;
            padding: 0;
            margin: 0 0 0 250px;
        }
        .navbar ul li a{
           display: block;
            text-decoration: none;
            font-size: 20px;
            text-align: center;
            padding:  5px 5px;
            font-family: Arial;
            font-weight:bold; 
        }
        .navbar ul:after{
            content: "";clear: both;
            display: block;
            
        }
        
        .navbar ul li{
            float: left;
            list-style: none;
    
        }
        
        .navbar ul ul{
            display: none;
        }
        .navbar ul li:hover>ul{
            display: block;
        }
        .navbar ul li:hover{
            background: black;
            transition: 0.9s;
        }
        .navbar ul li:hover a{
            color: white;
        }
       
        .navbar ul ul{
             background: black;
            padding: 0;
            margin: 0;
            position: absolute;top: 100%;
            
        }
        
        .navbar ul ul li{
            float: none;
            position: relative;
        }
        
        .navbar ul ul li a{
            padding:25px;
            color:white;
            width: 300px;
            text-align: left;
        }
        
        .navbar ul ul li a:hover{
            background: white;
            color: black;
            transition: 0.9s;
        }
        .logo img{
            position: absolute;
            margin-top: 10px;
            margin-left: 10px;
        }
        
         .form{
            font-family: "Robto",sans-serif;
            text-transform: uppercase;
            outline: 0;
            background: #fb2525;
            width:100%;
            border: 0;
            padding: 15px;
            color: #FFFFFF;
            font-size: 14px;
            cursor: pointer;
        }
        td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 28px 18px;
            background-color: white;
}
    
    </style>
    </head>
    <body>
    <div class ="logo"><a href ="#"><img src ="logo.png"></a>
        </div> 
        
    <div class="navbar">
        <ul>
            <li><a href ="#"><h1>PINELAND MUSIC SCHOOL</h1></a></li>
    <li><a href ="about.html">About us</a></li>
    <li><a href ="contact.html">contact</a></li>
    <li><a href ="feedback.html">feed back</a></li>
    <li><a href ="lesson_booking.html">Submit</a></li>
     <li><a href=""  ></a><img src="bar.jpg"> </li>
        </ul>
        </div>
        <br><br><br><br>
<table>
  <tr>
    <th>Instrument Type</th>
    <th>Student name</th>
    <th>Date and time</th>
  </tr>
    <tr>
    <th>Type of instrument</th>
    <th>name of the student</th>
    <th>Date and time of the lesson</th>
    </tr></table>
    


    </body>